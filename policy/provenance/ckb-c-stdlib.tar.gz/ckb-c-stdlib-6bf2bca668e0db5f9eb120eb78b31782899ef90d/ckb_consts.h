#ifndef CKB_C_STDLIB_CKB_CONSTS_H_
#define CKB_C_STDLIB_CKB_CONSTS_H_

#define SYS_exit 93
#define SYS_ckb_vm_version 2041
#define SYS_ckb_current_cycles 2042
#define SYS_ckb_exec 2043
#define SYS_ckb_load_transaction 2051
#define SYS_ckb_load_script 2052
#define SYS_ckb_load_tx_hash 2061
#define SYS_ckb_load_script_hash 2062
#define SYS_ckb_load_cell 2071
#define SYS_ckb_load_header 2072
#define SYS_ckb_load_input 2073
#define SYS_ckb_load_witness 2074
#define SYS_ckb_load_cell_by_field 2081
#define SYS_ckb_load_header_by_field 2082
#define SYS_ckb_load_input_by_field 2083
#define SYS_ckb_load_cell_data_as_code 2091
#define SYS_ckb_load_cell_data 2092
#define SYS_ckb_debug 2177
#define SYS_ckb_load_block_extension 2104
#define SYS_ckb_spawn 2601
#define SYS_ckb_wait 2602
#define SYS_ckb_process_id 2603
#define SYS_ckb_pipe 2604
#define SYS_ckb_write 2605
#define SYS_ckb_read 2606
#define SYS_ckb_inherited_fds 2607
#define SYS_ckb_close 2608

#define CKB_SUCCESS 0
#define CKB_INDEX_OUT_OF_BOUND 1
#define CKB_ITEM_MISSING 2
#define CKB_LENGTH_NOT_ENOUGH 3
#define CKB_INVALID_DATA 4
#define CKB_WAIT_FAILURE 5
#define CKB_INVALID_FD 6
#define CKB_OTHER_END_CLOSED 7
#define CKB_MAX_VMS_SPAWNED 8
#define CKB_MAX_FDS_CREATED 9

#define CKB_SOURCE_INPUT 1
#define CKB_SOURCE_OUTPUT 2
#define CKB_SOURCE_CELL_DEP 3
#define CKB_SOURCE_HEADER_DEP 4
#define CKB_SOURCE_GROUP_INPUT 0x0100000000000001
#define CKB_SOURCE_GROUP_OUTPUT 0x0100000000000002

#define CKB_CELL_FIELD_CAPACITY 0
#define CKB_CELL_FIELD_DATA_HASH 1
#define CKB_CELL_FIELD_LOCK 2
#define CKB_CELL_FIELD_LOCK_HASH 3
#define CKB_CELL_FIELD_TYPE 4
#define CKB_CELL_FIELD_TYPE_HASH 5
#define CKB_CELL_FIELD_OCCUPIED_CAPACITY 6

#define CKB_HEADER_FIELD_EPOCH_NUMBER 0
#define CKB_HEADER_FIELD_EPOCH_START_BLOCK_NUMBER 1
#define CKB_HEADER_FIELD_EPOCH_LENGTH 2

#define CKB_INPUT_FIELD_OUT_POINT 0
#define CKB_INPUT_FIELD_SINCE 1

#endif /* CKB_C_STDLIB_CKB_CONSTS_H_ */
